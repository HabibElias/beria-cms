# Berea — a community library, held open

A responsive library application connecting public book discovery, member borrowing, and library administration.

Live project: https://beriabooks.vercel.app

## The challenge

The existing library interface focused on managing books and members. Visitors needed a way to discover the collection, and readers needed accounts and a way to ask for a loan. Library administrators still needed control over availability, approvals, checkouts, and returns.

## The approach

- Keep browsing open to everyone, with search, categories, availability, and book details.
- Introduce member registration and sign-in, preserving the book a visitor wanted to borrow.
- Give readers one place to follow their active loans, due dates, and request decisions.
- Keep management behind an admin role and put pending requests in a dedicated review queue.
- Apply the supplied Berea identity across desktop, mobile, light, and dark interfaces.

## The connected workflow

A reader discovers a book, signs in or creates an account, and submits a request. An administrator reviews its context and approves or declines it. Approval creates the checkout and due date. The reader sees the result in their own account; a recorded return makes the copy available again. A pending request does not reserve a copy.

## What shipped

Public catalogue; member accounts; loan requests and cancellation; personal loan history; admin review, checkouts, and returns; responsive screens; light and dark themes; and a shared brand treatment.

The frontend uses React and TypeScript, hosted on Vercel. A separate Laravel API on Render connects to Turso. Authorization and loan availability are enforced by the backend as well as reflected in the interface.

## Validation and limits

The release passed 31 backend tests and an isolated browser workflow spanning browsing, registration, requesting, approval, and return. Post-deployment HTTPS checks confirmed the deployed assets, API connection, 16-book catalogue, and allowed frontend origin. These are implementation checks, not evidence of user research or measured business impact.

No adoption, conversion, satisfaction, or time-saved figures were measured. Add your actual role, collaborators, dates, research, and impact only when you can support them.

## Suggested portfolio sequence

1. Open with `boards/01-cover.png` and the one-sentence project description.
2. Explain the challenge and use `boards/02-reader-journey.png` to show the reader flow.
3. Show `boards/03-library-administration.png` to explain how requests connect to circulation.
4. Use `boards/04-brand-and-themes.png` to discuss the supplied identity, typography, and themes.
5. Add a link to the live project and describe your own contribution.

## Screenshot provenance

These are browser captures of the implemented frontend at the deployed release, using a separate local SQLite database and the actual Laravel API. Book metadata comes from the existing 16-book catalogue. Member names, contact addresses, requests, and loans are illustrative fixtures; no production member records were used or modified. Book jackets use the application's built-in fallback presentation. Presentation boards frame and arrange those screenshots; they do not depict additional features.

The logo is the application's current SVG emblem derived from the supplied brand material. The boards are portfolio presentation materials, not a reproduction of the brand-guideline document.
