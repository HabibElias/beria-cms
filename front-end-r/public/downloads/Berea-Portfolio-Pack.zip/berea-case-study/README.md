# Berea portfolio screenshot pack

## Included

- `boards/`: four ready-to-use presentation PNGs, each 3200 × 2000 px.
- `screenshots/`: clean 2× application captures for custom layouts, including full-page variants.
- `Berea-Case-Study.pdf`: the four presentation boards in one PDF.
- `case-study.html`: editable presentation source; open it in a browser while keeping this folder together.
- `CASE-STUDY.md`: concise case-study copy and suggested ordering.
- `assets/`: current brand emblem, Nunito font, and its license, used by the presentation source.
- `screenshot-manifest.json`: dimensions and capture details.

The clean desktop captures use a 1440 × 1000 CSS-pixel viewport; mobile uses 390 × 844. Device scale is 2×. The approval-dialog capture is a direct element screenshot. Files marked `full` include the entire scrollable page.

Use the boards for a portfolio gallery or presentation; use the clean screenshots for your own crops and compositions. The PDF is convenient for sharing the entire sequence.

All member data is fictional. The screens come from the working application using an isolated local API and database. No production accounts or loans were changed. See `CASE-STUDY.md` for provenance and limits. No performance or business-impact claims are implied.
